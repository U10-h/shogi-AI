Shogi Search Lab v0.16
16 actual games vs historical YaneuraOu NNUE 6.03. 1 second per move, two openings, colors reversed.
All 4 candidate configurations: 0 wins, 4 losses.
KIF includes the opening prefix. File names: opening-color-candidate.kif; color is the lab side.
